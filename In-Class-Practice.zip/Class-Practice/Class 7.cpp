// find mode of a list of numbers from 0 to 99
// NOT MY CODE

#include <iostream>
#include <stdexcept>
#include <vector>


typedef valueandfrequency{ // what is this?
    int value
    int frequency
}
// creates a type that includes other types

int main(){

    int current_value;
    std::vector <valueandfrequency> v;
    int maxfreq = 0;
    int mode = -1;


    while (std::cin >> current_value){

        try {
            if (current_value < 0 || current_value > 100){
                throw std::runtime_error("invalid number!");
            }
        }

        catch (std::exception e){
            std::cerr << e.what() << std::endl;
            std::exit;
        }

        for (int i = 0; i < i; i++){



        // for (int i = 0; 1 < 100; i++){ //old version

        //     if (freqs[i] > maxfreq){ //segmentation fault?
        //         maxfreq = freqs[i];
        //         mode = i;
            }
        }
    }
    std::cout << "mode is " << mode;
} // Ctrl + Z + Enter to exit loops