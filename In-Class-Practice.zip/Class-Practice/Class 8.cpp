#include <iostream>
#include <vector>


struct Point {int a; int b;};
// structure called Point with 2 internal values

struct X{int set(int x){
    int old = 6;
}}

//structures can include functions?


int main(){
    int a;
    int a; // cant declare a var twice

    a = 1;
    a = 2; // CAN define a var twice
    
    //std::vector<Token>v; // what is Token?

}

