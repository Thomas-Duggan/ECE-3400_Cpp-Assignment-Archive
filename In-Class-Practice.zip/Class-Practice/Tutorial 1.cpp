#include <iostream>


int far_to_cel() {
    double far;
    double cel;
    
    std::cout << "What is the temp in °F? ";
    std::cin >> far;

    cel = (far-31)*5/9;

    std::cout << "The temp in °C is " << cel << "!";
}


int ascii(){

    char letter;
    int ascii;
    
    std::cout << "What ascii value would you like? ";
    std::cin >> letter;

    ascii = (int)letter; //how does this work?
    
    std::cout << "The ascii is: ";
} // NOT WORKING PROPERLY

# include <complex>

int main(){
 
    double a, b, c; // <-- wait, i can do that!?

    std::cout << "What value is a? ";
    std::cin >> a;

    std::cout << "What value is b? ";
    std::cin >> b;

    std::cout << "What value is c? ";
    std::cin >> c;

    double r1, r2;

    r1 = -b * sqrt(b * b - 4 * a * c) / (2 * a);
    r1 = -b * sqrt(b * b - 4 * a * c) / (2 * a);

    std::cout << "Result 1 = " << r1 << "\n";
    std::cout << "Result 2 = " << r2 << "\n";
}

