// Sept 12th
// Language: build standard C++ library == True  (fix this)
// Change to standard C++ latest (fix this)

#include<iostream>
// Once settings are fixed, use:  import std; //imports C++ standard library

int main() 
{
//Note: C++ programs always start by running the "main()" function
    std::cout << "Hello World! \n"; //from the module "standard library", run the function "character output", and output the result, using the string "Hello World!" 
    // :: is basically the c++ version of Python's "from module(x) import function(y)"
    // \n is the new line operator when placed in a string        
    // << is the output operator
    return 0;   //Exits the function (not required in main() however)
} 

// int func();
// int g();
// void h();
// char *nothing;

// char string[5];

// func(string);

// void func(char *str) {

// }