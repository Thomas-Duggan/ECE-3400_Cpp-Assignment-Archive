////////////////////////// Matrix Class: operator overflowing //////////////////////////

// This should be an .hpp + .cpp file combo but ew no, we FOSS up in this mf.
#include <iostream>
#include <vector>

using namespace std;

class Matrix{
    public:
        
        // Constructor
        Matrix(int rows, int columns){
            try{
                if(rows < 0){throw runtime_error("number of rows is negative");}
                if(columns < 0) throw runtime_error("number of rows is negative");
            }       

            catch (exception e){
                cerr << "Exception: " << e.what() << endl;
            }
            
            int data = rows * columns;
            rows = rows;
            columns = columns;
        }

        // Assignment operator
        Matrix& operator=(const Matrix& other){ // & Reference reduces amount of data in RAM and speeds up the program. Const is to prevent editing original value.
            
            // this->columns = other.columns;       // BAD IMPLEMENTATION. DOES NOT CHECK DATA!
            // this->rows = other.rows;
            
            return *this; // returns pointer to left object ?? ⭐⭐⭐
        }

        // Equality operator
        bool operator==(const Matrix& other){ 

            // if (this->columns == other.columns && this->rows == this->columns){
            //     return true;     
            // }                        // BAD IMPLEMENTATION. DOES NOT CHECK DATA!
            // else{
            //     return false;
            // }
        }

        // Indexing operator
        double operator()(const /* could use unsigned here */ int row, const int column){ // Square brackets do not work here. Too many params.
            try{
                if (row < 0)           {throw runtime_error("Negative row");} // not required for unsigned int
                if (row >= rows)       {throw runtime_error("Row index beyond matrix");}
                if (column < 0)        {throw runtime_error("Negative column");} // not required for unsigned int
                if (column >= columns) {throw runtime_error("Column index beyond matrix");}     

                return data[row*columns + column]; // whats going on here?!?!?
            }

            catch (exception& e) {
                cerr << "Exception: " << e.what() << endl;
            }
        }

        // Addition operator
        Matrix& operator+(const Matrix& other){ 
            // this->columns += other.columns;  // BAD IMPLEMENTATION. DOES NOT CHECK DATA!
            // this->rows += other.rows;

            // proper implementation:
            // try{}
            // catch(exception e){cerr << "Exception: " << e.what() << };
            Matrix sum(rows,columns);


            return *this;
        }
        

    private:
        vector<double> data;

        unsigned int rows; // unsigned to prevent negatives
        unsigned int columns;
};


////////////////////////// TESTING //////////////////////////

int main(){
    Matrix A(3,3), B(3,3); // creates 3x3 matricies 

    // double a = 

}

// Note: .hpp and .h are the same