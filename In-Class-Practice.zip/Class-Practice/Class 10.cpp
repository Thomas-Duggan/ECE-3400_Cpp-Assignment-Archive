#include <iostream>
#include <vector>


class Class_Name { // creates a new data type
    
    public:
        int x;
        double y;   // private vars
        char z;     // can be accessed outside of the class
    
        // creating a function to access private vars is reccomended

    private:    // Note: values are private by default. This is only neccessary after a Public statement.
        int a;
        double b;   // private vars
        char c;     // cannot be accessed outside of the class

        int function(){ // most functions are typically left private, but not all
            // code here
            return 0;
        }

        // Structures / Classes are almost identical. They are meant for creating custom "types" with types inside a "subtype"
    

}; // <- Dont forget semicolon

int main(){
    std::cout << Class_Name.x; // not working?
    std::cout << Class_Name.a; // this one shouldn't work
    Class_Name.function();
}


////////////////////////////////////////////////////////////////

struct Structure_Name {
    // Like a class, but is always public
    // !! How are any of these different from just a definition?
    // instead of keeping out vars / functs in a def, should we keep them in here?

    int x;
    double y; 
    char z;

};  // <- Dont forget semicolon


int main(){
    std::cout << Structure_Name.x;
    Structure_Name.function();
   
}


////////////////////////////////////////////////////////////////



