#include <iostream>
#include <vector>
#include <memory> // smart pointers
#include <algorithm> // container functions (How do i make a container?)

#include <map>
#include <unordered_map> // dictionary includer
    map<string, int> dict;

using namespace std;

class test{};

// Algorithms
int main(){
    vector<test> container(3);

    container.begin(); // <- returns pointer to list[0]
    container.end();  // <- returns pointer to \0 

    iterator_ = iterator_ + 4; // random access iterator
    // Similar to arrays

    sort(container.begin(), container.end()-1, function_or_lambda); // sorts a list using a specific parameter
    is_sorted(container.begin(), container.end()-1); // checks if a list is sorted by lowest to highest

    container.unique_copy(container.begin(), container.end()-1); //duplicates removes duplicate values

    vector<int> v = {3, 1, 2, 1, 3};
    sort(v.begin(), v.end()); // sorts ascending
    vector<int> v2;
    unique_copy(v.begin(), v.end(), back_inserter(v2)); // copy unique elements


}

template <input_iterator ln, predicate<ln::value_type>Pred> // genuinely what the fuck is this?

// lambda expressions are expressions that do not have a name