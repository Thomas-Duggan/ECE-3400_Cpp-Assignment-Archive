#include <iostream>

int main(){

    int *p = new int; // allocates one int
    int *q = new int[7]; // allocates 7 ints (0 to 6)
    
    int n = 5;
    double *a = new double[n]; // allocates "n" amount of doubles

    *(a+2) = 0.1;
    *(q+1) = 8; // sets second allowcated value to 8
    // this is basically a list

    std::cout << *(q+1) << std::endl; // prints 8

    std::cout << *a << std::endl; // garbage value
    std::cout << *(a+1) << std::endl; // garbage value same as before
    std::cout << *(a+2) << std::endl; // prints 0.1
    // negative indexing is a thing, but not very useful


    /////////////////////////////////////////////

    double *p1 = new double[100];
    double *p2 = new double[100];

    p1[17] = 9.4;
    p2 = p1;
    // causes memory leak eventually

    delete p1;
    // prevents memory leak

    // you cannot set pointers of one type to a pointer of another type


    /////////////////////////////////////////////

    double *a1 = NULL; // points to nothing
    // same thing /\ \/
    double *a2 = nullptr; // points to nothing

    if (a1){ // if a is not null,
        *a1 = 0.001; // sets a value to a random place in RAM (dont do this)
    }
    
    // testing if a pointer isn't Null, its best to do this anyway
    if (a2){
        // only runs if RAM isn't full
    }


    /////////////////////////////////////////////

    double *calc(int result_size, int max){
        double *tmp - new double[max];
        double *result = new double[result_size];
        
        delete[] tmp; // each "new" should have a matching "delete"
        return result;
    }   // this isn't working ???

    double *r = calc(200,100);


    /////////////////////////////////////////////

    void f(){ //???
        double *p = new double[27];
    } 


    /////////////////////////////////////////////

    // Bohem garbage collector - fixes allocation leaks
    

    /////////////////////////////////////////////

    // destructor: removes element when no longer needed

    ~className(){delete[] elementName;}
    // gets called automatically if included in class
    // cannot delete nullptrs
    // 

}
