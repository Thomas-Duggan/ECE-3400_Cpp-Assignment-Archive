#include <iostream>  // only use old style
// Imports libraries
// <iostream> is the base library that you can
//    omit to reduce file size if required


///////////////////////////////////////////////////

// int = type to be returned
int not_main() {
    std::cout << "bingus \n";
//  ^^^  ^^^^ ^^unary 
//  ^^^  ^^^^object
//  ^^^namespace

return 0;
// can return any value, 0 = success
// returns 0 if omitted
}


///////////////////////////////////////////////////

void also_not_main() {
    std::cout << "bingus2\n";

// void cannot return values 
}


///////////////////////////////////////////////////

int i = 1.5;
// the variable "i" includes the integer 1.5

// int i = "string";
// "i" requires an int and this cannot work


///////////////////////////////////////////////////

using namespace std;
// allows you to not require "std"
//// CAN CAUSE ISSUES ////

int main(){            //                            \/ combines strings
    cout << "Please enter your first name (followed "<<"by enter)\n";
    string first_name; // defines first_name (string is an object of std btw)
    cin >> first_name; // input() value to first_name
    
}