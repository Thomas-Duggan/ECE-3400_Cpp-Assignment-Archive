#include <iostream>
#include <vector>

using namespace std;
// MT2 Practice problems available

//=============// TEMPLATES //=============//

// Parametric polymorphism: Using templates to create a script using many values
// Polymorphism: things that change


double* get_from_jack(int* count); // old C vector
vector<double>get_from_jill(); // C++ vector

int fctn(){
    int jack_count =0;
    double * jack_data = get_from_jack(&jack_count);
    delete[]jack_data;

    vector<double>jill_data = get_from_jill(); // much smaller
}

// Getting highest value in values:

double * jack_high;
double * jill_high;

for (int i = 0; i<jack_count; i++){
    if (h<jack_data[i]){
        jack_high = &jack_data[i]; // OLD C WAY
        h = jack_data[i];
    }
}


// Generaralized highest value finder. Works with old vectors and new vectors.
double *high(double* first, double* last){

    double h = -1;
    double* high;

    for (double *p = first; p!=last; ++p){
        if (h<*p){
            high = p;
            h = *p;
        }
    }
}

//=============// Replaces above: //=============//
#include<algorithm> // built in algorithms (sorting, finding values, finding values above a value, finding the first value, etc.)
//===============================================//
// 100 algorithms
// 12 containers

// ++ = go to next value
// * = get value

template<forward_iterator Iter> // What?
Iter high(Iter first, Iter last) // What?

// begin    <- gives first value of list
// end      <- gives last value of list