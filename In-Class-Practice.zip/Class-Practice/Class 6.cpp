#include <iostream>


/////////////////////////////////////////////////

int type_error(){
    char a = 'a';

    std::cout << a + 1; // appears correct but doesnt print expected answer
}


/////////////////////////////////////////////////

// in the event of illegal inputs, program should terminate with error code
// poor specification can cause error
// comments should always explain what code does


/////////////////////////////////////////////////

int syntax_error(){
    int x = 5;
    int y = 10;

    x =+ y; // this is incorrect but appears correct
    std::cout << x; // should print 15 but doesn't due to above error
}


//////////////////////////////////////////////////////////////////////////////////////////////////

int function(int x, int y){
    return x, y;
}

int calling_error(){
    function (5); // function requires multiple inputs
    function ('a', 7); // wont return expected result due to including a char
    function (2.1, 3.3); // calls with floats and will not return expected result
}


//////////////////////////////////////////////////////////////////////////////////////////////////

# include <stdexcept>

int exception_catching(){
    bool error = true;

    try{ // what does "try" do?
        if (error == true){
            throw std::runtime_error("Error: description name"); // exception value
        }       // why not just make a function that does cout directly? (its just standard practice to do this ig)
    }

    catch(std::runtime_error e){ // must always catch thrown errors
    std::cout << e.what(); // outputs value stored in runtime_error

    }
}

// if an error is fixable, try to fix it
// do not randomly change things in the program and hope for the best
// avoid nested loops / ifs

// both "\n" and '\n' work btw


//////////////////////////////////////////////////////////////////////////////////////////////////

int lowercase_vs_TitleCase(){
    std::cout << true; // lowercase works
    std::Cout << true; // TitleCase does not
}


//////////////////////////////////////////////////////////////////////////////////////////////////

int main(){
    char value = 'x';

    std::cerr << value; // cerr?
    
}