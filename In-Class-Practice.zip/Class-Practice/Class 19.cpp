#include <iostream>

int main(){
    void use (double *pd){
        pd[2] = 2.2;
        pd[3] = 3.3; // out of bounds with a 0 -> 2 array, but will set the value in RAM. Causes data corruption.
        pd[-2] = -2.2; // out of bounds with a 0 -> 2 array, but will set the value in RAM. Causes data corruption.
    }   // doesn't wrap

    void test{
        double arr[3]; // same?
        arr == &arr[0]; // same?
    }

    ////////////////////////////////////////

    double *p = new double;
    double *q = new double[1000];

    q[700] = 7.7; // item 700 in RAM list q is now 7.7
    q = p; // 700 data points are set to a data set with 1 data point, this cannot happen.

    // vector class fixes this issue

    ////////////////////////////////////////
    // pointer incrementation

    double ad[8]; // creates an array
    double *p = &ad[4]; //clones the address for the 4th item in ad

    *p = 7; // 
    p[2] = 6; // 2 elements to the right of where p points to
    p[-3] = 9; // 3 elements to the right of where p points to

    p = p + 2; // points to ad[6]

    ////////////////////////////////////////
    //pointer deincrementation

    *p = 7;
    p[2] = 6;
    p[-2] = 9;

    p += 2;

    p -= 4;

    ////////////////////////////////////////

    // Pointer arythmetic is used for low level programming / RAM managers
    // poor pointer arythmetic can cause Arbitrary Code Execution

    int *p = &x; // p is the address of x
    int &p = x; // p is an alias of x

    *p = 7; // 7 isn't a memory address

    ////////////////////////////////////////



}