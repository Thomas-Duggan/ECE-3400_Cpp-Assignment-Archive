#include <iostream>
#include <vector>

//===============// Templates //===============//

template<class T, int N> void fill(Buffer<T,N>& b) {/*...*/};
// fill = command
// void = return type
// T is the class (not existing rn)
// LESS CODE TO WRITE! 

template <class T> class Vector{ // parametric polymorphism <- the parameter changes the class
                                // Creates a generic class for use with any type you want
    // use "T" instead of characters, ints, doubles, etc 
    // When called, it replaces "T" with any value
};

//===============// Operator overflow //===============//

int main(){
    // Always define all essential operators (constructors, copys, etc) or define none

    // is there any reason to not use logical &&, ||
    
    // space: mem allocated but unused (\0 is always considered unused)


    //===============// Templates //===============//

    // Vectors of different types:
    //      Parametric polymorphism


}