#include <iostream>
#include <vector>

int enumeration(){
    enum class Class_Name{values}; // enumerated values of a class
    enum Var_Name {values}; // enumerated value of a variable
    enum {values}; // enumerated list of random values
    // Creates numbered references for items in a list.
        // Cant you just use List_name[i] ?
}


//////////////////////////////////////////////////

struct Month{
    int jan = 1;
    int feb = 2;
    int mar = 3;
    // ... etc.
};

class Date{
    public:
        Date(int y, int  m, int d); // why would you want a declaration not an actual function?
        int day() const; // gets a constant copy of the day, also a declartion, not a function.
        // Maybe declarations are public, and the actual code for each dec is private?

    private:
        int y;
        int m;
        int d;

        int day() const {
            return d;       // constant member, cannot modify
        }
        
        void add_day(int n){
            d += n ;
        };  // non-constant, CAN modify
};

bool operator == (const Date& a, const Date& b);
//redefines the "==" operator?  (operator overloading)
//redefinitions of mono operators can only have one operator in its redefinition

Month operator ++ (Month& m){
    m = (m==Month::jan)? Month::jan:Month(m+1);
//  ^                    ^^^^^^^^^^
// why "m"           why "Month::jan"

    //Same as:
    if (m == Month::jan){
        Month::jan;
    }
}

int main(){
    Date d {2000, Month::feb, 28}; // is d a constructor?
    const Date d2 {2005, Month::jan, 1};

    Date add_day(6);
}


/////////////////////////////////////////////////////////////

