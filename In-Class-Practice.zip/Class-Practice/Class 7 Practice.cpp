#include <iostream>
#include <vector>

int number_range = 10;

int main(){
    std::vector<int> numbers; 

    for (int reps = 0; reps != number_range; ++reps){
        numbers.push_back(reps);

        for (int length = numbers.size(); length >= reps; --length)

            if (length != reps){
                std::cout << numbers[length] << ",";
            }

            else{
                std::cout << numbers[length];
            }
        std::cout << "\n";
    }
}