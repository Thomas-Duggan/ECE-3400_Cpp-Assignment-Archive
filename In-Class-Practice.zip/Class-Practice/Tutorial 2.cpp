////// QUIZ /////

#include<iostream>

int main(){
    for (int i = 0; i < 100; i++) {
        std::cout << i << '\n';
    }
    ++i; // i is not available outside for loop
    std::cout << i << endl; // i is not avaiable outside for loop
        // endl requires std::

////////////////////////////////////////////

    double* values = new double[20];
    for (int i = 0; i < 20; i++){
        values[i] = i;
    }
    delete values; // should have square brackets?
        // seems to work fine though!
        // ASK SIR!!!
}
////////////////////////////////////////////

#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    int j = 0;
    for (int i = 0; i <= 4; i++)
    {
        if ((i <= 3) && (sqrt(3-i) > 0.5))
        {
            j += i;
        }
    }
    cout << "j=" << j << endl;
}

// answer is j=3
// know short-circuit & (&&) !!!

////////////////////////////////////////////

#include <iostream>
void square(int x)
    {
      x *= x;
    }

int main()
{
    int x = 3;
    square(x);
    std::cout << x << endl;
}

// x = 3 since square doesn't do anything outside of itself
// void doesn't return anything either
// &x creates a global copy of x

////////////////////////////////////////////

#include <iostream>
using namespace std;
int main()
{
    int temperatures[10] = {20, 14, 12, 21, 15, 22, 17, 20, 12, 16};
    short jumps[5] = {1, 2, 3, -4, 6};
    int *curtempptr = temperatures;
    for (int i = 0; i < 5; i++)
    {
        cout << *curtempptr << std::endl;
        curtempptr += jumps[i];
    }
}

// outputs:
// 20 (0)
// 14 (1)
// 21 (sum of 1 and 2)
// 17 (sum of 1 and 2 and 3)
// 12 (sum = 2)
// outputs nothing as i is less than 5

// Write explanation to maximize marks

////////////////////////////////////////////

// default constructor: defined by zero parameters (default values in a function)

// defaulted default constructor: constructor defined by compiler (var = uninitialized)

////// EXAM /////

#include <cassert>

using namespace std;

struct X {
    X (int i, int j): base(i), rem(base % j) { } //empty constructor, useless.
    int rem, base;
 };

 int main()
{
    X x(10, 5);
    assert(x.rem == 0);
}

// X is uninitialized ???
// Not required

////////////////////////////////////////////

#include <iostream>

int main()
{
    int i, &ri = i;
    i = 5; ri = 10;
    std::cout << i << " " << ri << std::endl;
}

// outputs:
// 10 10

// i changes due to ri being a reference to i
// ri = i makes ri an alias to i?

////////////////////////////////////////////

class Widget {
    public:
        Widget(int bufferSize) { // Constructor.
        // allocate some memory for buffer
        bufferPtr_ = new char[bufferSize];
    }
    private:
        char* bufferPtr_; // pointer to start of buffer
};

// Destrutor:
Widget::~Widget(){};

////////////////////////////////////////////

// Buffer question

// Copy constructor: Buffer(const Buffer& buffer){};
// Copy assignment: Buffer& operator=(const Buffer& buffer) {};

// defaulted copy assignment operater (dw about this)

// it would create a shallow copy (dw about this)

// Issue with copy operator: an object can be assigned to itself
    // deletes buffer before being assigned
    
// if (this != buffer){
// delete [] buffer_ptr}

////////////////////////////////////////////
// IMPORTANT

#include <iostream>

using namespace std;

class Complex { // Complex number type.
public:
    Complex(double x, double y) : x_(x), y_(y) {}
    double real() const {return x_;}
    double imag() const {return y_;}
    Complex operator*(double b) const;
private:
    double x_; // The real part.
    double y_; // The imaginary part.
};

Complex Complex::operator*(double b) const
{
    cout << "Overload 1" << endl;
    return Complex(x_*b, y_*b);
}

Complex operator*(double b, const Complex& a)
{
    cout << "Overload 2" << endl;
    return Complex(a.x_*b, a.y_*b); // not accessible!
}
    
int main() {
    Complex a(1.0, 2.0);
    Complex b(1.0, -2.0);
    double r = 2.0;
    Complex c = a*r;
    Complex d = r*a;
}

// Won't compile because x_ and y_ are private data members