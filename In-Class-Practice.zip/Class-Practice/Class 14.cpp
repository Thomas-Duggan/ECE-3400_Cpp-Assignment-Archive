#include <iostream>
#include <vector>

class test{ // test is the primary class
    virtual int function_name()=0;

    int test_ftn(int);
    int test_ftn(char); //same name, different parameter, WORKS!

    

}; 

class test1:test{ // test 1 is a subclass of test
    
    test1(const test1&) = delete; // <- Constructor; 
    int function_name(){
        
    }
}; 


class test2:test{}; // test 2 is a subclass of test


int main(){
    std::vector <test> {test1, test2}; // why is this not working?

}


/////////////////////////// Creating a vector class ///////////////////


class Vector(){
    int size;
    double* element; // creates a memory pointer 
    
    Public:
        Vector(int s); // declaration, not function
}

int* p = 600; // creates RAM address
int a = *p; // gives information at RAM address ???

:s(sz) // this still doesnt work
