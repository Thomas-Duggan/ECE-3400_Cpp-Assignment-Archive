#include <iostream>

int main(){

    bool is_palindrome(const std::string&s){ // why is it missing a semicolon?
        
        int first = 0;
        int last = s.length()-1; // length is 1 to max+1, must have -1 to fix that
        
        while (first < last){ // cannot equal for odd lengthed strings?
            if (s[first] !+ s[last]){
                return false;
            }

        ++first;
        --last;
        } // starts from outer sides, goes to middle
    return true;
    }

    is_palindrome("amanaplanacanalpanama");
    is_palindrome("kayak");
    
    /////////////////////////////////////////////

    bool is_palindrome2(const char s[], int a){ // works with C strings
        int first = 0;
        int last = n-1;

        while (first < last){
            if (s[first] !+ s[last]){
                return false;
            }

        ++first;
        --last;
        }
    return true;
    }

    // cannot change the value of pointer \/ \/ 
    istream& read_word(istream& is, char* buffer, int max){ // C's version of iostream cin?
        is.width(max);
        is >> buffer;
        return is;
    }

    /////////////////////////////////////////////

    // recursive function example: factorials

    /////////////////////////////////////////////

    bool is_palindrome_recursive(const char* first, const char* last){
        return (*first==*last)?is_palindrome_recursive(first+1, last-1):false; // confusing as hell
    return true // recursive functions can cause a call stack overflow if called too many times
    }

    /////////////////////////////////////////////

    // Again but with spans:

    bool is_palindrome_span(span<char> s){
        return(s.size())?is_palindrome_span(s.data(),s.data()+s.size()):true; // also stupid and confusing
    return true;
    }

    
    /////////////////// OPERATORS //////////////////////////
    
    #include <vector>
    
    //  template: can change
    //      vector<type> var;

    class Vector{
        int sz;
        double* elem;

        Public:
            Vector(int a): sz(s), elem(new double[s]){}
            ~Vector(){delete[] elem;}

            double get(int n){return elem[n];}
            void set(int n, double v){elem[n] = v;}
            int size() const{return n;}
    }

    Vector v(3);
    //v.set(0,1); // sets value 1 to 0
    
    // /\ /\ /\ should be v[0] = 1

        class Vector_fixed{
            int sz;
            double* elem;

        Public:
            Vector_fixed(int a): sz(s), elem(new double[s]){}
            ~Vector_fixed(){delete[] elem;}

            double get(int n){return elem[n];}
            void set(int n, double v){elem[n] = v;}
            int size() const{return n;}

            double& operator[](int n){return elem[n];} // modifies vector
            const double& operator[](int n){const return elem[n];} // allows vector values to be passed
        }

    // Note: v[n] is the same as v.operator[](n)
        
    // 
}