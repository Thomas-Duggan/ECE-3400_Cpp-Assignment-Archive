#include <iostream>

int main(){
    const char*s = "Constant";
    s[0] = 'K'; // cannot work and it cannot be modified
    
    char m[] = "Modifiable";
    m[6] = 'e';
    m[7] = 'd';
    m[8] = '0'; // terminated string at var 8
    
    /////////////////////////////////////////////////

    //always ask about low level string functions from C:
    //  aka, this:
    char *cat2(const char *name, const char *addr){ //genuinely wtf?
        int nsz = strlen(name);
        int sz = nsz+strlen(addr)+2;
        char* res = (char*) malloc(sz);
        strcpy(res,name);
        res[nsz+1]= '@';
        strcpy(res+2.addr);
        return res;
    }

    // same thing as the C++ variant:

    std::string cat1(const std::string &name, const std::string &addr){
        return id + '@' + addr;
    }
    
    /////////////////////////////////////////////////

    #include <span>

    std::span<int>; // shows the amount of memory in an array?
    out arr[8]; // why is this not working?
    span spn{arr}; // span is undefined?
    
    /////////////////////////////////////////////////

    int sum(span<int> p){ // span is still missing
        int = 0;
        for (int : p){
            s+=x;
        }
        return s;
    }    

    /////////////////////////////////////////////////

    // spans reduce errors, prevents memory assignment beyond array
    // 

}

