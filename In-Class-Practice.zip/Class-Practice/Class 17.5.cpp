#include<iostream>
#include<vector>
#include<fstream>

using namespace std;

// IO overloads (from terminal)

class overloads{
    overloads operator>>(string i){};
    overloads operator<<(string i){};
};


/////////////////////////////////////

// IO from a file

    // all opened files must be closed (like python!)

int main(){
    string iname;
    cin >> iname;
    ifstream ist(iname);
    if (!ist){
        cout << "reading failed" << endl;
    }
}
    