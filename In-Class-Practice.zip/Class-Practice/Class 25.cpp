#include <vector>

using namespace std;

double area_of_house(vector<vector<int>> rooms){ 

    double A;
    vector<vector<int>> rooms;

    for (int i=0; i<rooms.size(); i++)
        A += rooms[i][0] * rooms [i][1];

    return A;  
}

