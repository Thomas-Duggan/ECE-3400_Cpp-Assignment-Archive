#include<iostream>
#include<vector>

using namespace std;


struct Customer{
    string name;
    vector<string> addresses;
};


/////////////////////////////

class circle{};

class emoji:circle{
};


/////////////////////////////

class Shape{
};

Shape *fct(){ // ???
};

void user(){
    Shape *q = fct();
    delete q;
}


/////////////////////////////

// Smart pointers:

unique_ptr<Shape> fct(){
    Text tt {Point(100,100), "Ann"};
    return make_unique<Text>(Point{100,100},"Nick");

    //no longer needs delete ptr
}


/////////////////////////////

class Vector{ // Vector of doubles
    public:
        Vector(int s) :sz(s), elem{new double[s]} // error?
        ~Vector() {delete[] elem;}
        Vector operator[](int i){} // allows square bracket indexing

    private:
        int sz;
        double *elem;
};

Vector v(5); // creates a vector of 5 units wide

for (int i=0; i<v.size(); ++i){
    v.set(i,1,1*i);
    cout<< "v[" << i << "]==" << v.get(i) << endl;
}