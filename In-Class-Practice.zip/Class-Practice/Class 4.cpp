#include <iostream>


void type_safety() {
    
    int number = 2000;
    char letter = number; // This is valid C++, but will will not print "1000"
    int number_from_letter = letter; // takes lowest 8 bits?

    std::cout << "Number: " << number << "\n";
    std::cout << "Letter: " << letter << "\n"; //prints this unregistered unicode character: �
    std::cout << "Number from letter: " << number_from_letter << "\n"; // -48 ?!?!?
}


void uninitialized_vars(){
    int a;
    int b;
    int c;

    std::cout << a << "\n"; // 0
    std::cout << b << "\n"; // 6291192 <- weird...
    std::cout << c << "\n"; // 0
}   // creates garbage values
//  Note: just dont use auto type. Just dont do it.


void bin_to_char(){
    int bin = 97; // Note: Bin = Binary
    char letter = bin; // note: 97 is the binary value of the letter "a"

    std::cout << letter << "\n"; //prints "a"
}

//Remember: correct code is more important than efficient code
//  built-in fuctions exist for a reason though, make it clean at least

 
///////////////////////// computation /////////////////////////////////////////////
 
int or_vs_and (){ 
    int x = 1;
    int y = 2;

    if (x == 1 || x == 5){
        std::cout << "if statement 1 is true"; 
    } // is true since "||" = or

    if (x == 1 && x == 5){
        std::cout << "if statement 2 is true";
    } // is false since "&&" = and (only evaluates first? Shouldn't that only happen for or though?)
}
// Note: "==" is comparison operator, "=" is assignment operator
// Note: "++" increments a var by 1 and only 1

// preincrement: ++a (increments by 1)
// postincrement: a++ (unsure, but dont use it)

void constant_vars(){
    std:constexpr int x = 5;
    x = 2; // should show an error here since x is a constant expression and CANNOT CHANGE
}

// std::square() exists!
