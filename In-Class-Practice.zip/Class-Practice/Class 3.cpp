#include <iostream>
#include <string>

std::string str1 = "5";
// saves "1" for amount of chars and "5" for the value
std::string str2 = "10"; 
// saves "2" for amount of chars and "10" for the value

int int1 = 5;
int int2 = 10;

std::string char1 = "E";
// saves amount of letters in string
char char2 = 'E';
// does not save amount of letters in string, assumes "1"

const int constant = 5;
int constant = 20;

int main() {

    std::cout << str1 + str2 << "\n"; 
    // prints "510"
    std::cout << int1 + int2 << "\n"; 
    // prints "15"

    std::cout << 1 / 3 << "\n"; 
    //use something like this to find the amount of decimals printed
    // this doesnt work though

    std::cout << constant << "\n"; 
    // shows the first value of "constant" as it cannot change

}