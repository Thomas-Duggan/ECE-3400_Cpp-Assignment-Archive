

// are classes the only way to call a function from another script?


#include <iostream>
#include <cmath>


using namespace std;

///////////////// Main Class: //////////////////////////////////

// A mathematical vector in a three-dimensional space.
class ThreeVec {

    public:
        ThreeVec(double x, double y, double z);
        
        // Accessors 
        //   (const means you cannot change internal values)
        double getX() const { 
            return components[0]; 
        } 

        double getY() const {
            return components[1]; 
        } 
        
        double getZ() const {
            return components[2]; 
        } 

        double magitude() const; 

        // Calculate the sum of the squares of this vectors components.
        double magnitude() const;

        // Add this vector to another, returning the new vector.
        ThreeVec plus(const ThreeVec& v) const;
    
    private:
        double components[3];
}; // THIS PART WOULD BE IN HPP FILE FOR OBFUSCATION (ew)


///////////////// Helper functions: //////////////////////////////////
    // Help the class, but aren't part of the class

// Initializes the vector (not a Cpp vector, a math vector)
ThreeVec::ThreeVec(double x, double y, double z){
    components[0] = x;
    components[1] = y;
    components[2] = z;
}

// Return dot product between two vectors.
double dot(const ThreeVec& a, const ThreeVec& b){
    double output = 0.0;
    output = a.getX() * b.getX() + a.getX() * b.getY() + a.getZ() * b.getZ();
    return output;
};

// Print vector v to standard output.
void print(const ThreeVec& v){
    cout << "(" << v.getX() << ", " << v.getY() << ", " << v.getZ() << ")";
};

///////////////// Main Program: //////////////////////////////////

int main(){
    ThreeVec v(1,2,3);
    ThreeVec w(4,5,6);
    double x = dot(v,w);
    cout << "The dot product of ";
    print(v);
    cout << " and ";
    print(w);
    cout << " is " << dot(v,w);
}