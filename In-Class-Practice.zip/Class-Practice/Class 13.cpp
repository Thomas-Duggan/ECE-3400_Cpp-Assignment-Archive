#include <iostream>
#include <vector>
#include <qt> //not available

int guis(){
    using namepace Graph_lib; //???
}


//////////////////////////////////////

int main(){
    
}
