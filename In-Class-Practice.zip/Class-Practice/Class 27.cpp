#include <iostream>
#include <vector>

using namespace std;

//==============================================//
//=============// Smart pointers //=============//
//==============================================//

#include <memory> // Doesn't allow smart pointers to work ???

vector<int> make_vector(){  
    vector <int> res;       
    return res; // moves vector, does not copy 
}

unique_ptr<int> fctn(){  // smart pointer that self deletes
    // ...               // cannot be copied, can be moved
}
int make_unique() // turns shared to unique ???

shared_ptr<int> fctn(){  // smart pointer that self deletes
    //...                // can be copied and moved
}
int make_shared() // turns unique to shared ???

int unique_ptr p_unique; // issue ?
int shared_ptr p_shared; // issue ?
int *p_raw = 123; // raw pointer (C style)  [not deallocated after exit]


//=============// Special functions for smart pointers //=============// 

int *p_raw = get(p_not_raw) // turns unique/shared to raw
// Works for all smart pointers

p_new = p_original; // clones p_original to p_new
// SHARED POINTERS ONLY !!!

p_overwritten = move(p_retained); // moves p_retained to p_overwritten
// Works for all smart pointers

p1 = swap(p2); // swaps values of p1 and p2 (why would anyone want this?)
// Works for all smart pointers

//===================================================//
//=============// Maps (Dictionaries) //=============//
//===================================================//

map<string, string> balanced_dict = {
    {"key", "value"},
    {"key", "value"}, // balanced tree, saves alphabetically
    {"key", "value"},
    // etc.
};

map<string, string> unbalanced_dict = { // how to unbalanced maps look in code?
    {{{}, "value"}, "value"} // unbalanced tree, saves alphabetically 
};

undordered_map<string, string> unordered_dict = { // better
    {"key", "value"},
    {"key", "value"}, // saves in order assigned
    {"key", "value"},
}