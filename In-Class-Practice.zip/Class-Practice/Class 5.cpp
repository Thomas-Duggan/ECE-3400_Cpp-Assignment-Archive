
#include <iostream>

////////////////////////////////////////////////////////////////////////////////////////////////

int for_loops() {
    
    for (int i = 100; i < 100; i += 1){ // intialization (local); function; increment
                                        // without an initialization,it may go on forever
        std::cout << i;
    }

    // VS:

    int i = 100; // initialization (global)
    while (i < 100){ //function

        std::cout << i;
        
        i += 1; // increment
    }
}


///////////////////////////////////////////////////////////////////////////////////////////////////

int if_vs_else() {
    int x = 1;

    if (x == 2){
        std::cout << "yup!" << std::endl; // endl ends line instead of "\n"
    }
    else {
        std::cout << "nope!" << std::endl; // endl ends line instead of "\n"
    }

}


////////////////////////////////////////////////////////////////////////////////////////////////

#include <vector>
#include <algorithm>

int vectors(){

    std::vector<int> values; // dont forget to #include <vector>
    int temp;

    values.push_back(1); // adds a value to the beginning of the vector
    
    std::cout << values; //why doesn't this print?
    std::cout << values.size();
    std::cout << values[0];
    std::cout << values[1];

    std::cout << ranges::sort(values); // this should be part of #include <algorithm> though?

    //-------------------------------------------------------//

    std::vector<string> values_2 = {"Beta", "Alpha", "Charlie","Alpha"}; // I forget how to initialize a string

    std::cout << ranges::sort(values_2) //sort isnt working?
}
