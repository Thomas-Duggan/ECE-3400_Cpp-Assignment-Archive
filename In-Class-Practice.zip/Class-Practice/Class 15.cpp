#include <iostream>


int main(){
    int *p1 = new int(5); // allocates an integer for the pointer p1
    //  ^     ^^^     ^set the value to 5
    //  ^     ^^^allowcate space
    //  ^pointer variable

    std::cout << p1 << '\n'; // outputs RAM hex ID (ex: 0x6bad6)
    std::cout << *p1 << '\n'; //outputs the value of RAM hex ID
   

///////////////////////////////////////////////////////
    
    int *p2 = new int;
    p2[0] = 12; 

    std::cout << p2[0] << '\n';
    std::cout << p2[1] << '\n'; // outputs junk data


////////////////////////////////////////////////////////

    int *pi1 = new int(7);

    int *pi2 = pi1; // sets pi2 to the same RAM ID as pi1

    pi1[0] = 123; // sets value inside RAM (ID does not change)
    
    std::cout << pi1[0] << '\n'; // outputs same number
    std::cout << pi2[0] << '\n';


/////////////////////////////////////////////////////////

    int *p = nullptr; // creates an empty pointer

    delete p; // deletes allowcated area

    // for (int x = 0; x > 0; ++x){
    //     int *pointer = new int(x);
    // } // this should eventually cause a memory leak


/////////////////////////////////////////////////////////


    // std::cout << *0x6bad6 << '\n'; // can I read directly from a hex?
                                    // probably, but don't
}