#include <iostream>


////////////////////////////////////////////////

int x = 2;

void function1(int number){
    x = 5 + number;
}

void function2(int& number){
    x = 5 + number;
}

int dynamic_and_static_calls(){
    function1(x);
    std::cout << x;

    function2(x);
    std::cout << x;
}


////////////////////////////////////////////////

int call_stack_example(){

    funct_1(

        funct_2(

            funct_3(

                //example of a call stack
            )
        )
    )
}


////////////////////////////////////////////////

int a = 0;

int incr1(int a){
    return ++a;
}
int incr2(int& a){
    return ++a;
}


////////////////////////////////////////////////

int i = 7;
int& r = i;
r = 9; // why can I do this?
const int& cr = i;
i = 8;

main(){
    std::cout << cr << std::endl;
}


////////////////////////////////////////////////

