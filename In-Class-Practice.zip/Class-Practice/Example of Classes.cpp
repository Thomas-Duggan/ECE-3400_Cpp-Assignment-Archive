#include <iostream>

class Class {

    public:
        int x = 5;

        int x_value(){
            return x;
        }

        void x_increment(int n){
            x += n;
        }
};

int main(){
    Class copy0; // x = 5
    Class copy1; // x = 5 
    Class copy2; // x = 5
    
    // increment not called on copy0
    copy1.x_increment(5);  // x = 5+5  (10)
    copy2.x_increment(10); // x = 5+10 (15)

    std::cout << copy0.x_value() << '\n';
    std::cout << copy1.x_value() << '\n';
    std::cout << copy2.x_value() << '\n';
}

